# Changelog

## 2026.2.13

### Changes

- Version alignment with core Neer release numbers.

## 2026.2.6-3

### Changes

- Version alignment with core Neer release numbers.

## 2026.2.6-2

### Changes

- Version alignment with core Neer release numbers.

## 2026.2.6

### Changes

- Version alignment with core Neer release numbers.

## 2026.2.4

### Changes

- Version alignment with core Neer release numbers.

## 2026.2.2

### Changes

- Version alignment with core Neer release numbers.

## 2026.1.31

### Changes

- Version alignment with core Neer release numbers.

## 2026.1.30

### Changes

- Version alignment with core Neer release numbers.

## 2026.1.29

### Changes

- Version alignment with core Neer release numbers.

## 2026.1.23

### Features

- Initial Twitch plugin release
- Twitch chat integration via @twurple (IRC connection)
- Multi-account support with per-channel configuration
- Access control via user ID allowlists and role-based restrictions
- Automatic token refresh with RefreshingAuthProvider
- Environment variable fallback for default account token
- Message actions support
- Status monitoring and probing
- Outbound message delivery with markdown stripping

### Improvements

- Added proper configuration schema with Zod validation
- Added plugin descriptor (neer.plugin.json)
- Added comprehensive README and documentation
